def reverse(string):
    print("lox")	
    return string[::-1]
